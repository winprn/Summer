
# Contributing

You can contact me through [Discord server](https://discord.gg/x2v993HY7v) which mainly about Contribution

*Pull requests are welcome and for major changes, 
please open an issue first to discuss what you would like to change.*

*Pull request will be authorized as long as you're in the Discord server*

Please make sure to update tests as appropriate.

===

Since I'm don't actually understand how Github system work so you can teach me while in the Discord server

I'm waiting for your lovely contribution = )
